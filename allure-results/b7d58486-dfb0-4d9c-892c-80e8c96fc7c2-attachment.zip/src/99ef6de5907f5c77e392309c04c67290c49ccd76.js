// import { expect, test } from "@playwright/test";
// test("create link",async({page})=>{

// //  4. Test Case-4
// // -> Login to vtiger application
// // -> Click on Leads link
// // -> Click on create lead lookup image
// // -> Enter FirstName along  with dropdown ,  LastName and companyName
// // -> Click on save Btn
// // -> Verify whether the Lead is created with LastName and CompanyName in Lead Information page and Logout from the application.
//     await page.goto('http://49.249.29.4:8888')
//     let username="admin"
//     let password="admin"
//     await page.locator('//input[@type="text"]').fill(username)
//     await page.locator('//input[@type="password"]').fill(password)
//     await page.locator('//input[@type="submit"]').click()    
//     await page.getByText("Leads").click()
//     await page.getByTitle("Create Lead...").click()
//     await page.locator('//select[@name="salutationtype"]').selectOption("Mr.")
//     let first_name ="sai chand"
//     let last_name ="bandipally"
//     let company_name="cognizant"
//     await page.locator('//input[@name="firstname"]').fill(first_name)
//     await page.locator('//input[@name="lastname"]').fill(last_name)  
//     await page.locator('//input[@name="company"]').fill(company_name)
//     await page.getByRole("button",{name:"  Save  "}).first().click()
//     await expect(page.locator('//span[@id="dtlview_Last Name"]')).toHaveText(last_name)
//     await page.getByRole('img').nth(2).hover()
//     await page.getByRole('link', { name: 'Sign Out' }).click()





// })

//! Data driven framework using json

// import { expect, test } from "@playwright/test";
// import data from "../../Test_data/common_data.json"
// test("create link",async({page})=>{

// //  4. Test Case-4
// // -> Login to vtiger application
// // -> Click on Leads link
// // -> Click on create lead lookup image
// // -> Enter FirstName along  with dropdown ,  LastName and companyName
// // -> Click on save Btn
// // -> Verify whether the Lead is created with LastName and CompanyName in Lead Information page and Logout from the application.
//     await page.goto(data.url)
//     let username=data.user_name
//     let password=data.password
//     await page.locator('//input[@type="text"]').fill(username)
//     await page.locator('//input[@type="password"]').fill(password)
//     await page.locator('//input[@type="submit"]').click()    
//     await page.getByText("Leads").click()
//     await page.getByTitle("Create Lead...").click()
//     await page.locator('//select[@name="salutationtype"]').selectOption("Mr.")
//     let first_name ="sai chand"
//     let last_name ="bandipally"
//     let company_name="cognizant"
//     await page.locator('//input[@name="firstname"]').fill(first_name)
//     await page.locator('//input[@name="lastname"]').fill(last_name)  
//     await page.locator('//input[@name="company"]').fill(company_name)
//     await page.getByRole("button",{name:"  Save  "}).first().click()
import { expect, test } from "@playwright/test";
import { LoginPage } from "../../pages/login_page";
import { Workbook } from "exceljs";
import { Contact } from "../../pages/contact";
import path from "node:path";
import { DashBoardPage } from "../../pages/dashboard";
import { Leads } from "../../pages/leads";
import { title } from "node:process";
import { readExcel } from "../../utilities/Excel_utility";
for (let i=2;i<=6;i++)
    
{

test(`lead creation ${i}`,async({page})=>{
    test.slow()

  //? invoking login method from loginPage class
   let ln = new LoginPage(page)
   await ln.login()

    //? Reading data from excel sheet using utilities 
    
    let Title = readExcel("leads",i,2)
    let first_name = readExcel("leads",i,2)
    let last_name =  readExcel("leads",i,2)
    let leadsource =  readExcel("leads",i,2)
    let mon =   readExcel("leads",i,2)
    let year =   readExcel("leads",i,2)
    let date = `${mon}, ${year}`
    let day =  readExcel("leads",i,2)
    let company= readExcel("leads",i,2)

    //? invoking clickLeads function from DashBoardPage Class
    let db=new DashBoardPage(page)
    await db.clickLeads()

    //? involing create leads function from Leads page class to fill the details and save 
    let createLeads=new Leads(page)
    await createLeads.createLead(Title,first_name,last_name,company)
    
    //? Validating whether leads are saved or not using assertions 
    await expect(page.locator('//span[@id="dtlview_Last Name"]')).toHaveText(last_name)

    //? Logging out from the application 
    await page.getByRole('img').nth(2).hover()
    await page.getByRole('link', { name: 'Sign Out' }).click()





}) }